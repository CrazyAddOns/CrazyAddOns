Idle Timer management that performs actions after an amount of inactivity time of user for xbmc/kodi
